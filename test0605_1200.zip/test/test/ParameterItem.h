//
//  ParameterItem.h
//  test
//
//  Created by admin on 15/6/2.
//  Copyright (c) 2015年 moreChinese. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ParameterItem : NSObject
@property BOOL isEnumType;
@property NSString *name;
@property NSString *value;
@end
